You can clone the PINT repository from https://github.com/nanograv/PINT.
The github site has installation instructions and example PINT runs.

PINT can be run from python or a Jupyter notebook.

The command-line and GUI interface is pintk. To run:

pintk <parfile> <timfile>

############

For the .par and .tim files given here, I have slightly perturbed F0 and F1 (spin frequency and 1st derivative, or spindown rate) so you'll get to see more change when you fit.

> pintk J1513-5908.init.par  J1513-5908_topo.tim

or

> pintk J1513-5908.init.par  J1513-5908_bary.tim

When the GUI opens, it shows the pre-fit. Right now, no parameters are free, so your post-fit will look the same. At the top left, choose "spindown", and click on F0 and/or F1 to free those parameters. You can play around and see what happens when you free one at a time vs. both.

Once you've freed your parameters, click "Fit or "re-fit" at the bottom left. The residuals should be much flatter in the post-fit plot now.

You can also play with changing the x-axis (to MJD, year, etc.), and switching between pre- and post-fit, with the bar on the left.

When you are happy with your fit, click "Write par" at the bottom, and you can name a new parfile.


